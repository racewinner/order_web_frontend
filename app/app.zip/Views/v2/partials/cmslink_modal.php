<div id="cmslink_dialog" class="modal fade" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <div class="w-100 text-center">What do you want to do?</div>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body py-5 d-flex flex-column align-items-center">
                <button type='button' class="btn view-link w-75 border" data-bs-dismiss="modal">
                    View Link
                </button>
                <button type='button' class="btn show-me-products w-75 border mt-4" data-bs-dismiss="modal">
                    Show Me Products
                </button>
            </div>
        </div>
    </div>
</div>