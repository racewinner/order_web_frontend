<div class="my-cart sidebar right-sidebar collapsed" id="my-cart-sidebar">
    <div class="sidebar-content">
        <div class="my-cart-header d-flex p-4">
            <div class="flex-fill">
                <span class="trolley-icon me-2"><i class="bi bi-cart"></i></span>
                <span class="fw-bold">My Trolley</span>
            </div>
            <div>
                <button type="button" class="close" data-dismiss="sidebar">
                    <i class="bi bi-x"  style="font-size: 20px;"></i>
                </button>
            </div>
        </div>

        <div class="my-cart-content">
        </div>
    </div>
</div>