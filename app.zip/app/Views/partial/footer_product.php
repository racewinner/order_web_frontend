
</div>
<br>
<br>
<br>
<br>
<div id="footer"> <?php echo $this->lang->line('common_you_are_using_epos'); ?> <?php echo $this->config->item('application_version'); ?>.
</body>
</html>
