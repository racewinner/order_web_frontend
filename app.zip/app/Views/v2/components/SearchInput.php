<div class="position-relative search-input">
    <input class="form-control bg-white" 
        id="<?= $id ?>"
        name="<?= $name ?>" 
        value="<?= $value ?>"
        type="search" 
        placeholder="<?= $placeholder ?>" 
        aria-label="Search"
    >
    <button class="btn-search"><i class="fas fa-search"></i></button>
</div>
