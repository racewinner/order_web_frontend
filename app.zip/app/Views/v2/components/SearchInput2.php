<div class="position-relative search-input2">
    <input class="form-control bg-white" 
        id="<?= $id ?>"
        name="<?= $name ?>" 
        value="<?= $value ?>"
        type="search" 
        placeholder="<?= $placeholder ?>" 
        aria-label="Search"
        style="padding-right: 25px;"
    >
    <button class="btn-search"><i class="fas fa-search"></i></button>
</div>
