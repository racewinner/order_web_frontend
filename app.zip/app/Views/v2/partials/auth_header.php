<!-- Header START -->
<header class="">
    <div class="position-fixed top-0 start-0 end-0 d-flex justify-content-center d-none" id="ajax-call-indicator">
		<div class="spinner-border text-primary spinner-border-sm">
		</div>
        
	</div>
    <?= view("v2/partials/header_ribbon") ?>

    <div class="header-logo d-flex align-items-center">
        <a class="logo-image" href="/">
            <img class="logo" src="/assets/images/uws-logo.jpg" alt="logo">
        </a>
    </div>
</header>
