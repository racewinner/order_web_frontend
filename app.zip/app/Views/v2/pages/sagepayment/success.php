<h1>Payment Successful!</h1>
<p>Order ID: <?php echo $order_id; ?></p>
<p>Transaction ID: <?php echo $transaction_id; ?></p>
<p>Amount: £<?php echo number_format($amount, 2); ?></p>