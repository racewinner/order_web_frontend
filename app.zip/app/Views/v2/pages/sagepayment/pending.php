<h1>Payment Pending</h1>
<p>Your payment is being processed. Please wait...</p>